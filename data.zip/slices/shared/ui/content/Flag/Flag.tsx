import type { JSX } from "react";

type FlagProps = Omit<JSX.IntrinsicElements["img"], "src"> & {
	code: string;
};

export function Flag({ code, ...props }: FlagProps) {
	const src = `/images/flags/${code}.svg`;
	return <img alt={code} {...props} src={src} />;
}
