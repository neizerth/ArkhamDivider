import { injectGlobal } from "@emotion/css";

injectGlobal`
  @font-face {
    font-family: 'Breamcatcher';
    src: url('./Breamcatcher.woff') format('woff');
    font-weight: normal;
    font-style: normal;
  }
`;
