import { injectGlobal } from "@emotion/css";

injectGlobal`
  @font-face {
    font-family: 'ZhenShuai';
    src: url('./ZhenShuai-Regular.woff') format('woff');
    font-weight: normal;
    font-style: normal;
  }
`;
