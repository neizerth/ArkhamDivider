import { injectGlobal } from "@emotion/css";

injectGlobal`
  @font-face {
    font-family: 'SanCn';
    src: url('./SanCnM.ttf') format('truetype');
    font-weight: normal;
    font-style: normal;
  }

  @font-face {
    font-family: 'SanCn';
    src: url('./SanCnB.ttf') format('truetype');
    font-weight: bold;
    font-style: normal;
  }
`;
