export const T_LINK = import.meta.env.VITE_T_LINK;
export const PAYPAL_LINK = import.meta.env.VITE_PAYPAL_LINK;
export const GITHUB_LINK = import.meta.env.VITE_GITHUB_LINK;
export const BOOSTY_LINK = import.meta.env.VITE_BOOSTY_LINK;
export const PATREON_LINK = import.meta.env.VITE_PATREON_LINK;
