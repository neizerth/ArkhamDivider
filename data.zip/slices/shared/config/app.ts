export const API_URL = import.meta.env.VITE_BASE_URL as string;
export const ARKHAMESQUE_API_URL = import.meta.env
	.VITE_ARKHAMESQUE_URL as string;
