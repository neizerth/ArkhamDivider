import type { Action, ThunkAction } from "@reduxjs/toolkit";
import { configureStore } from "@reduxjs/toolkit";
import createSagaMiddleware, { type SagaMiddleware } from "redux-saga";
import reducer from "./reducer";
import { rootSaga } from "./sagas";

// Типы для store

export type AppStore = ReturnType<typeof createStore>;
export type RootState = ReturnType<AppStore["getState"]>;
export type AppDispatch = AppStore["dispatch"];

export type AppThunk<ReturnType = void> = ThunkAction<
	ReturnType,
	RootState,
	unknown,
	Action
>;

export type AppSelector<ReturnType = unknown> = (
	state: RootState,
) => ReturnType;

export const createStore = () => {
	const sagaMiddleware: SagaMiddleware = createSagaMiddleware();
	const store = configureStore({
		reducer,
		middleware: (getDefaultMiddleware) => {
			const middleware = getDefaultMiddleware();
			middleware.push(sagaMiddleware);
			return middleware;
		}
	});

	sagaMiddleware.run(rootSaga);

	return store;
};
