import { modulesReducer } from "@/modules/reducer";

export default {
	...modulesReducer,
};
