import * as C from './MainMenu.components'

type MainMenuProps = {

}

export function MainMenu({}: MainMenuProps) {
  return (
    <C.Container>
      <h1>MainMenu.tsx</h1>
    </C.Container>
  );
}