import { Logo as BaseLogo } from "@/shared/ui";
import { styled } from "@mui/material/styles";

export const Container = styled("header")(({ theme }) => ({
	padding: theme.spacing(2),
}));

export const Logo = styled(BaseLogo)`
	width: 50px;
`;
