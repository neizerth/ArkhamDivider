import type { AutocompleteRenderInputParams } from "@mui/material/Autocomplete";
import * as C from "./LanguageSwitch.components";
import TextField from "@mui/material/TextField";
import { useTranslation } from "react-i18next";

type LanguageSwitchProps = {
	languages: string[];
};

export function LanguageSwitch({ languages }: LanguageSwitchProps) {
	const { t } = useTranslation();

	const renderInput = (params: AutocompleteRenderInputParams) => {
		return <TextField {...params} label={t`Language`} />;
	};
	return <C.Container options={languages} renderInput={renderInput} />;
}
