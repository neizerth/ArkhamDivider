export const CHINA_LANGUAGES = ["zh", "zh-cn"];
export const DEFAULT_LANGUAGE = "en";

export const i18nNamespace = {
	default: "core",
	custom: "custom",
};
