export { default as i18n } from "./i18n";
