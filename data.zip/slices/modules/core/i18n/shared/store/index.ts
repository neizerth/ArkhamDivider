export * from "./i18n";
export * as i18nReducer from "./reducer";
