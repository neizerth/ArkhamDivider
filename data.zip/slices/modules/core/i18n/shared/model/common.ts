export type Translation = Record<string, string>;
