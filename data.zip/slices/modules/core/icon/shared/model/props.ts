export type BaseIconProps = {
	icon: string;
};
