import { coreModulesReducer } from "./core/reducer";

export const modulesReducer = {
	...coreModulesReducer,
};
