import * as C from "./HomePage.components";

export function HomePage() {
	return (
		<C.Container>
			<h1>HomePage.tsx</h1>
		</C.Container>
	);
}
