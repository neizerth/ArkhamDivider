import styled from "@emotion/styled";
import { SingleColumnLayout } from "@/widgets/layout/SingleColumnLayout";

export const Container = styled(SingleColumnLayout)`

`;
